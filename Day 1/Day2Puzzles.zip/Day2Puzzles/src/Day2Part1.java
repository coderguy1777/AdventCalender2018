import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Collections;

public class Day2Part1 {
    public static ArrayList<String> liststorage = new ArrayList<>();
    public static ArrayList<Integer> listhashes = new ArrayList<>();
    public static HashMap<Integer, String>listhash = new HashMap<>();
    public static int count = 0;

    public static void main(String[] args) {
        try {
            Scanner scan;
            scan = new Scanner(new BufferedReader(new FileReader("input2puzzle2.txt")));
            while (scan.hasNextLine()) {
                String listscanner = scan.nextLine();
                double sum = 0;
                if(listscanner.startsWith("prtkq")) {
                    sum += listscanner.hashCode();
                }
                System.out.println(sum);

                liststorage.add(listscanner);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
        Collections.sort(liststorage);
        for (int i = 0; i < liststorage.size(); i++) {
            System.out.println(liststorage.get(i).trim());
            listhashes.add(liststorage.get(i).hashCode());
        }
        Collections.sort(listhashes);
        for (int x = 0; x < listhashes.size(); x++) {
            listhash.put(listhashes.get(x), liststorage.get(x));
        }
    }

    public static void CheckSumMethod(Map mp) {
        Iterator it = mp.entrySet().iterator();
        int s = 0;
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            System.out.println(pair.getKey() + " = " + pair.getValue());
            it.remove(); // avoids a ConcurrentModificationException
            float sum = 0f;
        }
    }
}